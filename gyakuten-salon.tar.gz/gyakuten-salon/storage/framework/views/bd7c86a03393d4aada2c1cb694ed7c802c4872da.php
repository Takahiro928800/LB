<?php $__env->startSection('content'); ?>

    <div class="container mt-4">
       
        <div class="mb-4">
            <div class="card-header mb-2">
                <?php echo e($post->title); ?>

            </div>
            <div class="card-body">
                <p class="card-text">
                    <?php echo e($post->body); ?>

                </p>
                
            </div>
            <div class="card-footer">
                <span class="mr-2">
                    投稿日時
                </span>
            </div>
        </div>
        <div class="mt-4 text-right">
            <a class="btn btn-primary" href="<?php echo e(route('posts.edit',['post' => $post])); ?>">
                編集
            </a>
            
            <form
            style="display: inline-block;"
            method="POST"
            action="<?php echo e(route('posts.destory'. ['post' => $post])); ?>"
            >
                <?php echo e(csrf_field()); ?>

                <?php echo e(method_field('DELETE')); ?>

                <button class="btn btn-danger">削除</button>
            
            </form>
        </div>
    </div>
    
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>